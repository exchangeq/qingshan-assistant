#!/data/data/com.termux/files/usr/bin/bash

cd /storage/emulated/0/qingshan
./qingshan
