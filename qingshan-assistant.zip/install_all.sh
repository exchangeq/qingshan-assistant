#!/data/data/com.termux/files/usr/bin/bash

# 设置颜色
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
PURPLE='\033[1;35m'
CYAN='\033[1;36m'
NC='\033[0m'

echo -e "${PURPLE}"
echo "╔══════════════════════════════════════════╗"
echo "║      青山辅助 完整安装包                 ║"
echo "║          版本: 专业隐藏版                ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}[*] 正在更新系统...${NC}"
pkg update -y && pkg upgrade -y

echo -e "${YELLOW}[*] 安装必要工具...${NC}"
pkg install clang make cmake git nano -y

echo -e "${YELLOW}[*] 创建项目目录...${NC}"
mkdir -p ~/qingshan_assist
cd ~/qingshan_assist

echo -e "${YELLOW}[*] 下载脚本文件...${NC}"

# 创建所有脚本文件
cat > setup_permissions.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
echo "悬浮窗权限配置脚本"
EOF

cat > start_assist.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
echo "启动脚本"
EOF

cat > build_assist.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
echo "编译脚本"
EOF

# 给执行权限
chmod +x *.sh

echo -e "${YELLOW}[*] 配置存储权限...${NC}"
termux-setup-storage

echo -e "${YELLOW}[*] 创建隐藏目录...${NC}"
mkdir -p ~/storage/shared/.Android/.config
mkdir -p ~/storage/shared/.Android/.cache
mkdir -p ~/.hidden_config

echo -e "${GREEN}[✓] 安装完成!${NC}"
echo ""
echo -e "${CYAN}可用命令:${NC}"
echo -e "${YELLOW}1. ${NC}./setup_permissions.sh - 配置权限"
echo -e "${YELLOW}2. ${NC}./build_assist.sh - 编译程序"
echo -e "${YELLOW}3. ${NC}./start_assist.sh - 启动辅助"
echo ""
echo -e "${RED}重要: 使用前请配置悬浮窗权限${NC}"
echo -e "${BLUE}按回车键继续...${NC}"
read