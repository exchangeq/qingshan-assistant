#!/data/data/com.termux/files/usr/bin/bash

echo -e "\033[1;35m"
echo "╔══════════════════════════════════════════╗"
echo "║       QINGSHAN ASSISTANT SETUP          ║"
echo "║          权限配置向导 v1.0              ║"
echo "╚══════════════════════════════════════════╝"
echo -e "\033[0m"

echo -e "\033[1;33m[*] 正在检查系统权限...\033[0m"
sleep 1

echo -e "\033[1;34m[1] 正在申请悬浮窗权限...\033[0m"
echo -e "\033[1;36m请按照以下步骤操作:\033[0m"
echo "1. 打开手机设置"
echo "2. 进入应用管理"
echo "3. 找到Termux应用"
echo "4. 开启'在其他应用上层显示'权限"
echo "5. 开启'显示悬浮窗'权限"
echo ""
echo -e "\033[1;33m按回车键继续...\033[0m"
read

echo -e "\033[1;34m[2] 正在配置存储权限...\033[0m"
termux-setup-storage
sleep 2

echo -e "\033[1[34m[3] 创建配置文件目录...\033[0m"
mkdir -p ~/storage/shared/.system_config
mkdir -p ~/storage/shared/.game_data
mkdir -p ~/storage/shared/.assist_cache

echo -e "\033[1[32m[✓] 目录创建完成:\033[0m"
echo "~/.system_config - 系统配置文件"
echo "~/.game_data - 游戏数据缓存"
echo "~/.assist_cache - 辅助运行缓存"

echo -e "\033[1[34m[4] 配置环境变量...\033[0m"
echo 'export ASSIST_PATH="~/.system_config"' >> ~/.bashrc
echo 'export GAME_CACHE="~/.game_data"' >> ~/.bashrc
echo 'export HIDE_MODE=1' >> ~/.bashrc

echo -e "\033[1[34m[5] 设置隐藏模式...\033[0m"
touch ~/.hidden_mode_enabled
echo "hide_location=true" > ~/.system_config/privacy.cfg
echo "hide_health=true" >> ~/.system_config/privacy.cfg
echo "stealth_mode=true" >> ~/.system_config/privacy.cfg

echo -e "\033[1[32m[✓] 隐藏模式已激活:\033[0m"
echo "- 不显示玩家位置"
echo "- 不显示血量信息"
echo "- 启用隐身模式"

echo -e "\033[1[34m[6] 配置完成!\033[0m"
echo ""
echo -e "\033[1[36m运行以下命令启动辅助:\033[0m"
echo -e "\033[1[33m./start_assist.sh\033[0m"
echo ""
echo -e "\033[1[35m按回车键返回...\033[0m"
read