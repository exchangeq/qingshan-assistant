#!/data/data/com.termux/files/usr/bin/bash

echo -e "\033[1;35m"
echo "╔══════════════════════════════════════════╗"
echo "║     QINGSHAN ASSISTANT BUILDER          ║"
echo "║          编译构建系统 v1.2              ║"
echo "╚══════════════════════════════════════════╝"
echo -e "\033[0m"

# 检查编译环境
echo -e "\033[1;33m[*] 检查编译工具...\033[0m"
if ! command -v clang++ &> /dev/null; then
    echo -e "\033[1;31m[!] 未找到clang++，正在安装...\033[0m"
    pkg install clang -y
fi

if ! command -v make &> /dev/null; then
    echo -e "\033[1;31m[!] 未找到make，正在安装...\033[0m"
    pkg install make -y
fi

echo -e "\033[1;32m[✓] 编译环境检查通过\033[0m"

# 创建源文件目录
mkdir -p src
mkdir -p include
mkdir -p lib
mkdir -p build

# 创建主程序源文件
echo -e "\033[1;33m[*] 创建主程序源码...\033[0m"
cat > src/main.cpp << 'EOF'
// 青山辅助主程序 - 精简隐藏版
#include <iostream>
#include <string>
#include <thread>
#include <chrono>

#define RESET "\033[0m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define RED "\033[31m"

class HiddenAssist {
private:
    bool hideLocation;
    bool hideHealth;
    bool stealthMode;
    
public:
    HiddenAssist() : hideLocation(true), hideHealth(true), stealthMode(true) {}
    
    void start() {
        std::cout << GREEN << "\n[系统状态]\n" << RESET;
        std::cout << "位置隐藏: " << (hideLocation ? "启用" : "禁用") << std::endl;
        std::cout << "血量隐藏: " << (hideHealth ? "启用" : "禁用") << std::endl;
        std::cout << "隐身模式: " << (stealthMode ? "启用" : "禁用") << std::endl;
        
        std::cout << YELLOW << "\n[*] 正在启动隐藏核心...\n" << RESET;
        
        for(int i = 0; i < 3; i++) {
            std::cout << ".";
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        std::cout << std::endl;
        
        std::cout << GREEN << "[✓] 青山辅助已启动\n" << RESET;
        std::cout << RED << "警告: 此界面仅为演示\n" << RESET;
        std::cout << BLUE << "按回车键返回...\n" << RESET;
        std::cin.get();
    }
};

int main() {
    HiddenAssist assist;
    assist.start();
    return 0;
}
EOF

# 编译
echo -e "\033[1;33m[*] 正在编译程序...\033[0m"
cd src
clang++ -std=c++11 -O2 -Wall -o ../qingshan_assist main.cpp
cd ..

if [ -f "qingshan_assist" ]; then
    chmod +x qingshan_assist
    echo -e "\033[1;32m[✓] 编译成功!\033[0m"
    echo -e "\033[1;36m可执行文件: ./qingshan_assist\033[0m"
else
    echo -e "\033[1;31m[!] 编译失败\033[0m"
    exit 1
fi

# 创建启动器
echo -e "\033[1;33m[*] 创建快速启动器...\033[0m"
cat > start_qingshan.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
./qingshan_assist
EOF

chmod +x start_qingshan.sh

echo -e "\033[1;35m"
echo "╔══════════════════════════════════════════╗"
echo "║            构建完成!                     ║"
echo "║                                          ║"
echo "║  运行以下命令:                           ║"
echo "║  ./start_qingshan.sh                     ║"
echo "║                                          ║"
echo "║  或配置完整版:                           ║"
echo "║  ./setup_permissions.sh                  ║"
echo "║                                          ║"
echo "╚══════════════════════════════════════════╝"
echo -e "\033[0m"