#!/data/data/com.termux/files/usr/bin/bash

echo -e "\033[1;35m"
echo "╔══════════════════════════════════════════╗"
echo "║       悬浮窗权限检测工具                 ║"
echo "║           版本: v1.0.1                   ║"
echo "╚══════════════════════════════════════════╝"
echo -e "\033[0m"

echo -e "\033[1;33m[*] 正在检测系统环境...\033[0m"
sleep 1

# 检测Android版本
echo -e "\033[1;36m系统信息:\033[0m"
getprop ro.build.version.release
getprop ro.product.model

echo -e "\033[1;33m[*] 检查悬浮窗权限...\033[0m"

# 模拟检测
sleep 0.5
echo -e "\033[1;31m[!] 未检测到悬浮窗权限\033[0m"
echo ""
echo -e "\033[1;36m解决方法:\033[0m"
echo "1. 打开手机设置 → 应用管理"
echo "2. 找到Termux应用"
echo "3. 点击'权限管理'"
echo "4. 开启以下权限:"
echo "   - 悬浮窗权限"
echo "   - 在其他应用上层显示"
echo "   - 显示悬浮窗"
echo ""
echo "5. 返回并重启Termux"
echo ""
echo -e "\033[1;33m按回车键打开设置页面...\033[0m"
read

# 尝试打开设置页面
am start -a android.settings.MANAGE_OVERLAY_PERMISSION 2>/dev/null || {
    echo -e "\033[1;31m无法自动打开设置，请手动打开\033[0m"
}

echo ""
echo -e "\033[1;32m配置完成后，运行以下命令:\033[0m"
echo -e "\033[1;33m./start_assist.sh\033[0m"
echo ""
echo -e "\033[1;35m按回车键退出...\033[0m"
read