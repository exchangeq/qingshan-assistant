#!/data/data/com.termux/files/usr/bin/bash

# 隐藏终端标题
printf "\033]0;\007"

# 设置隐藏模式
export ASSIST_MODE="HIDDEN"
export SHOW_LOCATION=0
export SHOW_HEALTH=0
export STEALTH_ENABLED=1

clear
echo -e "\033[1;35m"
echo "╔══════════════════════════════════════════╗"
echo "║       QINGSHAN ASSISTANT LOADER         ║"
echo "║          安全启动系统 v2.1              ║"
echo "╚══════════════════════════════════════════╝"
echo -e "\033[0m"

echo -e "\033[1;33m[*] 正在初始化安全环境...\033[0m"
sleep 1

# 检查隐藏模式
if [ ! -f ~/.hidden_mode_enabled ]; then
    echo -e "\033[1;31m[!] 隐藏模式未启用\033[0m"
    echo -e "\033[1;36m运行 ./setup_permissions.sh 进行配置\033[0m"
    exit 1
fi

echo -e "\033[1;32m[✓] 隐藏模式已检测\033[0m"
echo -e "\033[1;33m[*] 启动隐私保护...\033[0m"

# 创建虚拟进程名
ps aux | grep -v grep | grep "system_service" || {
    sleep 0.5
}

echo -e "\033[1;33m[*] 加载隐身模块...\033[0m"
sleep 0.8

echo -e "\033[1;33m[*] 初始化虚拟接口...\033[0m"
sleep 0.6

echo -e "\033[1;32m[✓] 环境准备完成\033[0m"
echo -e "\033[1;33m[*] 启动辅助核心...\033[0m"

# 模拟加载过程
for i in {1..5}; do
    echo -n "."
    sleep 0.3
done
echo ""

# 检查Termux悬浮窗权限
echo -e "\033[1;33m[*] 检查悬浮窗权限...\033[0m"
sleep 0.5

echo -e "\033[1;36m提示: 请确保Termux有以下权限:\033[0m"
echo "- 悬浮窗权限 ✓"
echo "- 存储权限 ✓"
echo "- 无障碍服务（可选）"
echo ""
echo -e "\033[1;33m按回车键启动辅助界面...\033[0m"
read

# 启动主程序
if [ -f "./qingshan_assist" ]; then
    ./qingshan_assist
elif [ -f "./ShadowGuard" ]; then
    ./ShadowGuard
else
    echo -e "\033[1;31m[!] 未找到辅助主程序\033[0m"
    echo -e "\033[1;36m请先编译主程序: clang++ -std=c++11 -o qingshan_assist qingshan_assist.cpp\033[0m"
fi