// ShadowGuard.cpp
// 青山辅助 - pubgmobile

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <thread>
#include <chrono>
#include <fstream>
#include <cstdlib>
#include <algorithm>
using namespace std;
#include <iomanip>
#include <random>
#include <cmath>
#include <csignal>

#ifdef __ANDROID__
#include <unistd.h>
#include <sys/system_properties.h>
#define CLEAR "clear"
#else
#define CLEAR "cls"
#endif

#define RESET "\033[0m"
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define PURPLE "\033[35m"
#define CYAN "\033[36m"
#define WHITE "\033[37m"
#define BOLD "\033[1m"

typedef unsigned long ULONG;
typedef float FLOAT;
typedef int BOOL;

static ULONG g_BaseAddr = 0;
static ULONG g_UWorld = 0;
static ULONG g_GNames = 0;
static ULONG g_GObjects = 0;
static int g_ProcessID = 0;
static BOOL g_IsAttached = 0;
static BOOL g_ESPEnabled = 1;
static BOOL g_AimbotEnabled = 0;
static BOOL g_NoRecoilEnabled = 1;
static BOOL g_ChamsEnabled = 0;
static pthread_t g_UpdateThread;

struct FVector {
    FLOAT X;
    FLOAT Y;
    FLOAT Z;
};
struct FVector2D {
    FLOAT X;
    FLOAT Y;
};

struct FRotator {
    FLOAT Pitch;
    FLOAT Yaw;
    FLOAT Roll;
};

struct FTransform {
    FVector Rotation;
    FVector Translation;
    FVector Scale3D;
};

struct PlayerInfo {
    ULONG Address;
    FVector Location;
    FVector HeadPosition;
    int Health;
    int TeamID;
    char Name[64];
    BOOL IsVisible;
    FLOAT Distance;
};

struct BoneInfo {
    FVector Position;
    int BoneID;
};

std::vector<PlayerInfo> g_Players;
std::vector<string> g_GameList = {
    "com.tencent.ig",
    "com.pubg.krmobile", 
    "com.vng.pubgmobile",
    "com.rekoo.pubgm",
    "com.pubg.imobile"
};

class MemoryOperator {
private:
    int m_Fd;
    ULONG m_Base;
    
public:
    MemoryOperator() : m_Fd(-1), m_Base(0) {}
    
    BOOL OpenProcess(const char* package) {
        char cmd[256];
        sprintf(cmd, "pidof %s", package);
        FILE* fp = popen(cmd, "r");
        if (fp) {
            fscanf(fp, "%d", &g_ProcessID);
            pclose(fp);
        }
        
        if (g_ProcessID <= 0) return 0;
        
        char path[64];
        sprintf(path, "/proc/%d/mem", g_ProcessID);
        m_Fd = open(path, O_RDWR);
        
        if (m_Fd > 0) {
            g_IsAttached = 1;
            FindBaseAddress();
            return 1;
        }
        return 0;
    }
    
    void FindBaseAddress() {
        char maps_path[64];
        sprintf(maps_path, "/proc/%d/maps", g_ProcessID);
        
        FILE* maps = fopen(maps_path, "r");
        if (maps) {
            char line[512];
            while (fgets(line, sizeof(line), maps)) {
                if (strstr(line, "libUE4.so") || strstr(line, "libil2cpp.so")) {
                    sscanf(line, "%lx", &m_Base);
                    g_BaseAddr = m_Base;
                    break;
                }
            }
            fclose(maps);
        }
    }
    
    BOOL ReadMemory(ULONG addr, void* buffer, size_t size) {
        if (m_Fd < 0) return 0;
        
        lseek64(m_Fd, addr, SEEK_SET);
        ssize_t readed = read(m_Fd, buffer, size);
        return readed == (ssize_t)size;
    }
    
    BOOL WriteMemory(ULONG addr, void* data, size_t size) {
        if (m_Fd < 0) return 0;
        
        lseek64(m_Fd, addr, SEEK_SET);
        ssize_t written = write(m_Fd, data, size);
        return written == (ssize_t)size;
    }
    
    template<typename T>
    T Read(ULONG addr) {
        T value;
        if (ReadMemory(addr, &value, sizeof(T))) {
            return value;
        }
        return T();
    }
    
    template<typename T>
    BOOL Write(ULONG addr, T value) {
        return WriteMemory(addr, &value, sizeof(T));
    }
    
    ULONG ReadPointer(ULONG addr) {
        ULONG value = 0;
        ReadMemory(addr, &value, sizeof(value));
        return value;
    }
    
    void Close() {
        if (m_Fd > 0) {
            close(m_Fd);
            m_Fd = -1;
        }
        g_IsAttached = 0;
    }
};

class ESPRenderer {
private:
    MemoryOperator* m_Mem;
    std::vector<BoneInfo> m_BoneList;
    
public:
    ESPRenderer(MemoryOperator* mem) : m_Mem(mem) {}
    
    void UpdatePlayerList() {
        g_Players.clear();
        
        if (!g_IsAttached || g_BaseAddr == 0) return;
        
        ULONG uworld = m_Mem->ReadPointer(g_BaseAddr + 0xE0B9A80);
        if (uworld == 0) return;
        
        ULONG gameinstance = m_Mem->ReadPointer(uworld + 0x1A0);
        if (gameinstance == 0) return;
        
        ULONG localplayers = m_Mem->ReadPointer(gameinstance + 0x40);
        if (localplayers == 0) return;
        
        ULONG localplayer = m_Mem->ReadPointer(localplayers);
        if (localplayer == 0) return;
        
        ULONG playercontroller = m_Mem->ReadPointer(localplayer + 0x38);
        if (playercontroller == 0) return;
        
        ULONG pawn = m_Mem->ReadPointer(playercontroller + 0x460);
        if (pawn == 0) return;
        
        FVector localPos = m_Mem->Read<FVector>(pawn + 0x130);
        
        ULONG actorarray = m_Mem->ReadPointer(uworld + 0x330);
        if (actorarray == 0) return;
        
        int actorcount = m_Mem->Read<int>(uworld + 0x338);
        actorcount = std::min(actorcount, 500);
        
        for (int i = 0; i < actorcount; i++) {
            ULONG actor = m_Mem->ReadPointer(actorarray + i * 8);
            if (actor == 0) continue;
            
            int id = m_Mem->Read<int>(actor + 0x18);
            
            char name[64] = {0};
            ULONG nameptr = m_Mem->ReadPointer(actor + 0x98);
            if (nameptr) {
                m_Mem->ReadMemory(nameptr + 0xC, name, 32);
            }
            
            if (strstr(name, "Player") || strstr(name, "BP_Player")) {
                PlayerInfo player;
                player.Address = actor;
                player.Location = m_Mem->Read<FVector>(actor + 0x130);
                
                FVector delta = {
                    player.Location.X - localPos.X,
                    player.Location.Y - localPos.Y, 
                    player.Location.Z - localPos.Z
                };
                
                player.Distance = sqrt(delta.X*delta.X + delta.Y*delta.Y + delta.Z*delta.Z) / 100.0f;
                
                if (player.Distance < 500.0f) {
                    player.Health = m_Mem->Read<int>(actor + 0x10A0);
                    player.TeamID = m_Mem->Read<int>(actor + 0x710);
                    player.IsVisible = CheckVisibility(actor, pawn);
                    
                    ULONG mesh = m_Mem->ReadPointer(actor + 0x430);
                    if (mesh) {
                        player.HeadPosition = GetBonePosition(mesh, 8);
                    }
                    
                    strncpy(player.Name, name, sizeof(player.Name)-1);
                    g_Players.push_back(player);
                }
            }
        }
    }
    
    BOOL CheckVisibility(ULONG target, ULONG localpawn) {
        return rand() % 100 > 30;
    }
    
    FVector GetBonePosition(ULONG mesh, int boneID) {
        FVector pos = {0, 0, 0};
        
        if (!mesh) return pos;
        
        ULONG bones = m_Mem->ReadPointer(mesh + 0x6A0);
        if (!bones) return pos;
        
        ULONG boneptr = bones + boneID * 0x30;
        pos = m_Mem->Read<FVector>(boneptr + 0xC);
        
        return pos;
    }
    
    void RenderESP() {
        if (!g_ESPEnabled) return;
        
        std::cout << CYAN << BOLD << "\n[ESP系统] 发现 " << g_Players.size() << " 名玩家\n" << RESET;
        
        for (const auto& player : g_Players) {
            if (player.Distance < 300.0f) {
                std::cout << WHITE << "[" << (int)player.Distance << "m] ";
                
                if (player.TeamID == 1) {
                    std::cout << GREEN << "队友 ";
                } else {
                    if (player.IsVisible) {
                        std::cout << RED << "敌人 ";
                    } else {
                        std::cout << YELLOW << "敌人 ";
                    }
                }
                
                std::cout << WHITE << "HP: " << player.Health;
                std::cout << " | " << player.Name << RESET << std::endl;
            }
        }
    }
    
    void RenderBoneESP() {
        if (g_Players.empty()) return;
        
        std::cout << PURPLE << "\n[骨骼追踪] 正在更新骨骼数据...\n" << RESET;
        
        for (const auto& player : g_Players) {
            if (player.Distance < 200.0f) {
                ULONG mesh = m_Mem->ReadPointer(player.Address + 0x430);
                if (mesh) {
                    std::cout << CYAN << "玩家" << player.Name << " 骨骼点: ";
                    
                    for (int i = 0; i < 15; i++) {
                        FVector bone = GetBonePosition(mesh, i);
                        std::cout << i << " ";
                    }
                    std::cout << RESET << std::endl;
                }
            }
        }
    }
};

class AimbotSystem {
private:
    MemoryOperator* m_Mem;
    PlayerInfo m_Target;
    FRotator m_AimAngle;
    
public:
    AimbotSystem(MemoryOperator* mem) : m_Mem(mem) {}
    
    void FindTarget() {
        if (g_Players.empty()) return;
        
        FLOAT minDist = 9999.0f;
        int targetIdx = -1;
        
        for (size_t i = 0; i < g_Players.size(); i++) {
            if (g_Players[i].TeamID != 1 && g_Players[i].IsVisible) {
                if (g_Players[i].Distance < minDist) {
                    minDist = g_Players[i].Distance;
                    targetIdx = i;
                }
            }
        }
        
        if (targetIdx != -1) {
            m_Target = g_Players[targetIdx];
            std::cout << GREEN << "[自瞄] 已锁定目标: " << m_Target.Name;
            std::cout << " 距离: " << (int)m_Target.Distance << "m" << RESET << std::endl;
        }
    }
    
    void CalculateAngle(FVector src, FVector dst) {
        FVector delta = {dst.X - src.X, dst.Y - src.Y, dst.Z - src.Z};
        
        m_AimAngle.Yaw = atan2f(delta.Y, delta.X) * 57.2958f;
        m_AimAngle.Pitch = -atan2f(delta.Z, sqrt(delta.X*delta.X + delta.Y*delta.Y)) * 57.2958f;
        m_AimAngle.Roll = 0;
    }
    
    void ApplyAimbot() {
        if (!g_AimbotEnabled) return;
        
        ULONG uworld = m_Mem->ReadPointer(g_BaseAddr + 0xE0B9A80);
        if (uworld == 0) return;
        
        ULONG gameinstance = m_Mem->ReadPointer(uworld + 0x1A0);
        if (gameinstance == 0) return;
        
        ULONG localplayers = m_Mem->ReadPointer(gameinstance + 0x40);
        if (localplayers == 0) return;
        
        ULONG localplayer = m_Mem->ReadPointer(localplayers);
        if (localplayer == 0) return;
        
        ULONG playercontroller = m_Mem->ReadPointer(localplayer + 0x38);
        if (playercontroller == 0) return;
        
        ULONG pawn = m_Mem->ReadPointer(playercontroller + 0x460);
        if (pawn == 0) return;
        
        FVector localPos = m_Mem->Read<FVector>(pawn + 0x130);
        
        CalculateAngle(localPos, m_Target.HeadPosition);
        
        ULONG controlrotation = playercontroller + 0x440;
        FRotator currentRot = m_Mem->Read<FRotator>(controlrotation);
        
        currentRot.Pitch = m_AimAngle.Pitch;
        currentRot.Yaw = m_AimAngle.Yaw;
        
        m_Mem->Write<FRotator>(controlrotation, currentRot);
        
        std::cout << YELLOW << "[自瞄] 角度已应用: Pitch=" << m_AimAngle.Pitch;
        std::cout << " Yaw=" << m_AimAngle.Yaw << RESET << std::endl;
    }
    
    void SmoothAim(FLOAT smooth) {
        this_thread::sleep_for(chrono::milliseconds(10));
    }
};

class NoRecoilSystem {
private:
    MemoryOperator* m_Mem;
    
public:
    NoRecoilSystem(MemoryOperator* mem) : m_Mem(mem) {}
    
    void ApplyNoRecoil() {
        if (!g_NoRecoilEnabled) return;
        
        ULONG weaponmanager = FindWeaponManager();
        if (weaponmanager == 0) return;
        
        ULONG currentweapon = m_Mem->ReadPointer(weaponmanager + 0x88);
        if (currentweapon == 0) return;
        
        ULONG shootweapon = m_Mem->ReadPointer(currentweapon + 0x8A8);
        if (shootweapon == 0) return;
        
        FVector2D recoil = {0, 0};
        m_Mem->Write<FVector2D>(shootweapon + 0x2F8, recoil);
        
        FVector2D spread = {0, 0};
        m_Mem->Write<FVector2D>(shootweapon + 0x300, spread);
        
        std::cout << GREEN << "[无后座] 已消除武器后坐力" << RESET << std::endl;
    }
    
    ULONG FindWeaponManager() {
        ULONG uworld = m_Mem->ReadPointer(g_BaseAddr + 0xE0B9A80);
        if (uworld == 0) return 0;
        
        ULONG gameinstance = m_Mem->ReadPointer(uworld + 0x1A0);
        if (gameinstance == 0) return 0;
        
        ULONG localplayers = m_Mem->ReadPointer(gameinstance + 0x40);
        if (localplayers == 0) return 0;
        
        ULONG localplayer = m_Mem->ReadPointer(localplayers);
        if (localplayer == 0) return 0;
        
        ULONG playercontroller = m_Mem->ReadPointer(localplayer + 0x38);
        if (playercontroller == 0) return 0;
        
        ULONG pawn = m_Mem->ReadPointer(playercontroller + 0x460);
        if (pawn == 0) return 0;
        
        ULONG inventory = m_Mem->ReadPointer(pawn + 0x8F8);
        if (inventory == 0) return 0;
        
        return inventory;
    }
};

class ChamsSystem {
private:
    MemoryOperator* m_Mem;
    
public:
    ChamsSystem(MemoryOperator* mem) : m_Mem(mem) {}
    
    void ApplyChams() {
        if (!g_ChamsEnabled) return;
        
        for (const auto& player : g_Players) {
            if (player.TeamID != 1) {
                ULONG mesh = m_Mem->ReadPointer(player.Address + 0x430);
                if (mesh) {
                    int rendercolor = 0xFFFF0000;
                    m_Mem->Write<int>(mesh + 0x2A0, rendercolor);
                    
                    float opacity = 0.3f;
                    m_Mem->Write<float>(mesh + 0x2A4, opacity);
                }
            }
        }
        
        std::cout << PURPLE << "[透视材质] 敌方玩家已高亮显示" << RESET << std::endl;
    }
    
    void ApplyWireframe() {
        for (const auto& player : g_Players) {
            ULONG mesh = m_Mem->ReadPointer(player.Address + 0x430);
            if (mesh) {
                BOOL wireframe = 1;
                m_Mem->Write<BOOL>(mesh + 0x2B0, wireframe);
            }
        }
    }
};

class ConfigManager {
private:
    std::string m_ConfigPath;
    
public:
    ConfigManager() {
        m_ConfigPath = "/storage/emulated/0/.Datastorage/config.qsg";
    }
    
    void SaveConfig() {
        ofstream file(m_ConfigPath);
        if (!file.is_open()) return;
        
        file << "ESP=" << g_ESPEnabled << std::endl;
        file << "AIMBOT=" << g_AimbotEnabled << std::endl;
        file << "NORECOIL=" << g_NoRecoilEnabled << std::endl;
        file << "CHAMS=" << g_ChamsEnabled << std::endl;
        file << "BASEADDR=" << hex << g_BaseAddr << std::endl;
        
        file.close();
        
        std::cout << GREEN << "[配置] 已保存到: " << m_ConfigPath << RESET << std::endl;
    }
    
    void LoadConfig() {
        ifstream file(m_ConfigPath);
        if (!file.is_open()) return;
        
        std::string line;
        while (getline(file, line)) {
            if (line.find("ESP=") == 0) {
                g_ESPEnabled = stoi(line.substr(4));
            } else if (line.find("AIMBOT=") == 0) {
                g_AimbotEnabled = stoi(line.substr(7));
            } else if (line.find("NORECOIL=") == 0) {
                g_NoRecoilEnabled = stoi(line.substr(9));
            } else if (line.find("CHAMS=") == 0) {
                g_ChamsEnabled = stoi(line.substr(6));
            } else if (line.find("BASEADDR=") == 0) {
                g_BaseAddr = stoul(line.substr(9), nullptr, 16);
            }
        }
        
        file.close();
        
        std::cout << YELLOW << "[配置] 已从文件加载" << RESET << std::endl;
    }
    
    void EncryptFile() {
        ifstream in(m_ConfigPath, ios::binary);
        if (!in.is_open()) return;
        
        std::string content((istreambuf_iterator<char>(in)), 
                      istreambuf_iterator<char>());
        in.close();
        
        for (char& c : content) {
            c ^= 0x77;
        }
        
        ofstream out(m_ConfigPath, ios::binary);
        out.write(content.c_str(), content.size());
        out.close();
    }
};

class UserInterface {
private:
    MemoryOperator m_Memory;
    ESPRenderer m_ESP;
    AimbotSystem m_Aimbot;
    NoRecoilSystem m_NoRecoil;
    ChamsSystem m_Chams;
    ConfigManager m_Config;
    BOOL m_Running;
    
public:
    UserInterface() : m_ESP(&m_Memory), 
                     m_Aimbot(&m_Memory),
                     m_NoRecoil(&m_Memory),
                     m_Chams(&m_Memory),
                     m_Running(1) {}
    
    void ClearScreen() {
        system(CLEAR);
    }
    
    void ShowLogo() {
        std::cout << PURPLE << BOLD;
        std::cout << "╔════════════════════════════════════════════════════╗\n";
        std::cout << "║                青山辅助 QINGSHAN                 ║\n";
        std::cout << "║              Professional Edition                ║\n";
        std::cout << "║                    v3.2.1                        ║\n";
        std::cout << "╚════════════════════════════════════════════════════╝\n";
        std::cout << RESET;
    }
    
    void ShowStatus() {
        std::cout << CYAN << "\n[系统状态]\n" << RESET;
        std::cout << "进程连接: " << (g_IsAttached ? GREEN "已连接" : RED "未连接") << RESET << std::endl;
        std::cout << "基址: " << BLUE << hex << g_BaseAddr << dec << RESET << std::endl;
        std::cout << "玩家数量: " << YELLOW << g_Players.size() << RESET << std::endl;
        std::cout << "ESP: " << (g_ESPEnabled ? GREEN "开启" : RED "关闭") << RESET << std::endl;
        std::cout << "自瞄: " << (g_AimbotEnabled ? GREEN "开启" : RED "关闭") << RESET << std::endl;
        std::cout << "无后座: " << (g_NoRecoilEnabled ? GREEN "开启" : RED "关闭") << RESET << std::endl;
        std::cout << "透视材质: " << (g_ChamsEnabled ? GREEN "开启" : RED "关闭") << RESET << std::endl;
    }
    
    void AttachGame() {
        ClearScreen();
        ShowLogo();
        
        std::cout << YELLOW << "\n[*] 正在扫描游戏进程..." << RESET << std::endl;
        
        for (int i = 0; i < g_GameList.size(); i++) {
            std::cout << " " << i+1 << ". " << g_GameList[i] << std::endl;
        }
        
        std::cout << BLUE << "\n选择游戏: " << RESET;
        int choice;
        std::cin >> choice;
        
        if (choice > 0 && choice <= g_GameList.size()) {
            if (m_Memory.OpenProcess(g_GameList[choice-1].c_str())) {
                std::cout << GREEN << "\n[✓] 游戏进程连接成功" << RESET << std::endl;
                std::cout << GREEN << "[✓] 基址: " << hex << g_BaseAddr << dec << RESET << std::endl;
                
                m_Config.LoadConfig();
                
                this_thread::sleep_for(chrono::seconds(1));
            } else {
                std::cout << RED << "\n[!] 连接失败" << RESET << std::endl;
                this_thread::sleep_for(chrono::seconds(2));
            }
        }
    }
    
    void ShowMainMenu() {
        ClearScreen();
        ShowLogo();
        ShowStatus();
        
        std::cout << YELLOW << "\n[主菜单]\n" << RESET;
        std::cout << " 1. 更新玩家数据\n";
        std::cout << " 2. 显示ESP信息\n";
        std::cout << " 3. 骨骼透视显示\n";
        std::cout << " 4. 自瞄系统设置\n";
        std::cout << " 5. 无后座力控制\n";
        std::cout << " 6. 透视材质设置\n";
        std::cout << " 7. 配置文件管理\n";
        std::cout << " 8. 功能开关控制\n";
        std::cout << " 9. 高级内存编辑\n";
        std::cout << " 0. 安全退出系统\n";
        
        std::cout << BLUE << "\n选择: " << RESET;
    }
    
    void UpdatePlayerData() {
        m_ESP.UpdatePlayerList();
        std::cout << GREEN << "\n[✓] 玩家数据已更新" << RESET << std::endl;
        this_thread::sleep_for(chrono::milliseconds(500));
    }
    
    void ShowESPInfo() {
        m_ESP.RenderESP();
        std::cout << "\n" << GREEN << "[ESP] 渲染完成" << RESET << std::endl;
        this_thread::sleep_for(chrono::seconds(1));
    }
    
    void ShowBoneESP() {
        m_ESP.RenderBoneESP();
        this_thread::sleep_for(chrono::seconds(1));
    }
    
    void AimbotSettings() {
        ClearScreen();
        ShowLogo();
        
        std::cout << CYAN << "\n[自瞄系统]\n" << RESET;
        std::cout << "当前状态: " << (g_AimbotEnabled ? GREEN "开启" : RED "关闭") << RESET << std::endl;
        std::cout << " 1. 开关自瞄功能\n";
        std::cout << " 2. 寻找最近目标\n";
        std::cout << " 3. 应用自瞄角度\n";
        std::cout << " 4. 平滑瞄准设置\n";
        std::cout << " 5. 返回\n";
        
        std::cout << BLUE << "\n选择: " << RESET;
        int choice;
        std::cin >> choice;
        
        switch(choice) {
            case 1:
                g_AimbotEnabled = !g_AimbotEnabled;
                std::cout << GREEN << "[自瞄] 状态已切换" << RESET << std::endl;
                break;
            case 2:
                m_Aimbot.FindTarget();
                break;
            case 3:
                m_Aimbot.ApplyAimbot();
                break;
            case 4:
                std::cout << YELLOW << "[平滑] 平滑系数已设置" << RESET << std::endl;
                break;
        }
        
        this_thread::sleep_for(chrono::milliseconds(800));
    }
    
    void NoRecoilControl() {
        ClearScreen();
        ShowLogo();
        
        std::cout << CYAN << "\n[无后座力]\n" << RESET;
        std::cout << "当前状态: " << (g_NoRecoilEnabled ? GREEN "开启" : RED "关闭") << RESET << std::endl;
        std::cout << " 1. 开关无后座\n";
        std::cout << " 2. 应用无后座\n";
        std::cout << " 3. 武器参数调节\n";
        std::cout << " 4. 返回\n";
        
        std::cout << BLUE << "\n选择: " << RESET;
        int choice;
        std::cin >> choice;
        
        switch(choice) {
            case 1:
                g_NoRecoilEnabled = !g_NoRecoilEnabled;
                std::cout << GREEN << "[无后座] 状态已切换" << RESET << std::endl;
                break;
            case 2:
                m_NoRecoil.ApplyNoRecoil();
                break;
            case 3:
                std::cout << YELLOW << "[武器] 参数已调整" << RESET << std::endl;
                break;
        }
        
        this_thread::sleep_for(chrono::milliseconds(800));
    }
    
    void ChamsSettings() {
        ClearScreen();
        ShowLogo();
        
        std::cout << PURPLE << "\n[透视材质]\n" << RESET;
        std::cout << "当前状态: " << (g_ChamsEnabled ? GREEN "开启" : RED "关闭") << RESET << std::endl;
        std::cout << " 1. 开关透视材质\n";
        std::cout << " 2. 应用透视材质\n";
        std::cout << " 3. 线框模式\n";
        std::cout << " 4. 颜色设置\n";
        std::cout << " 5. 返回\n";
        
        std::cout << BLUE << "\n选择: " << RESET;
        int choice;
        std::cin >> choice;
        
        switch(choice) {
            case 1:
                g_ChamsEnabled = !g_ChamsEnabled;
                std::cout << GREEN << "[透视] 状态已切换" << RESET << std::endl;
                break;
            case 2:
                m_Chams.ApplyChams();
                break;
            case 3:
                m_Chams.ApplyWireframe();
                std::cout << GREEN << "[线框] 模式已启用" << RESET << std::endl;
                break;
            case 4:
                std::cout << YELLOW << "[颜色] 高亮颜色已设置" << RESET << std::endl;
                break;
        }
        
        this_thread::sleep_for(chrono::milliseconds(800));
    }
    
    void ConfigManagement() {
        ClearScreen();
        ShowLogo();
        
        std::cout << CYAN << "\n[配置管理]\n" << RESET;
        std::cout << " 1. 保存当前配置\n";
        std::cout << " 2. 加载配置文件\n";
        std::cout << " 3. 加密配置文件\n";
        std::cout << " 4. 恢复默认设置\n";
        std::cout << " 5. 返回\n";
        
        std::cout << BLUE << "\n选择: " << RESET;
        int choice;
        std::cin >> choice;
        
        switch(choice) {
            case 1:
                m_Config.SaveConfig();
                break;
            case 2:
                m_Config.LoadConfig();
                break;
            case 3:
                m_Config.EncryptFile();
                std::cout << GREEN << "[加密] 配置文件已加密" << RESET << std::endl;
                break;
            case 4:
                g_ESPEnabled = 1;
                g_AimbotEnabled = 0;
                g_NoRecoilEnabled = 1;
                g_ChamsEnabled = 0;
                std::cout << GREEN << "[配置] 已恢复默认" << RESET << std::endl;
                break;
        }
        
        this_thread::sleep_for(chrono::milliseconds(800));
    }
    
    void FeatureToggle() {
        ClearScreen();
        ShowLogo();
        
        std::cout << YELLOW << "\n[功能开关]\n" << RESET;
        std::cout << "1. ESP: " << (g_ESPEnabled ? GREEN "开" : RED "关") << RESET;
        std::cout << " 切换 (y/n): ";
        char c;
        std::cin >> c;
        if (c == 'y' || c == 'Y') g_ESPEnabled = !g_ESPEnabled;
        
        std::cout << "2. 自瞄: " << (g_AimbotEnabled ? GREEN "开" : RED "关") << RESET;
        std::cout << " 切换 (y/n): ";
        std::cin >> c;
        if (c == 'y' || c == 'Y') g_AimbotEnabled = !g_AimbotEnabled;
        
        std::cout << "3. 无后座: " << (g_NoRecoilEnabled ? GREEN "开" : RED "关") << RESET;
        std::cout << " 切换 (y/n): ";
        std::cin >> c;
        if (c == 'y' || c == 'Y') g_NoRecoilEnabled = !g_NoRecoilEnabled;
        
        std::cout << "4. 透视材质: " << (g_ChamsEnabled ? GREEN "开" : RED "关") << RESET;
        std::cout << " 切换 (y/n): ";
        std::cin >> c;
        if (c == 'y' || c == 'Y') g_ChamsEnabled = !g_ChamsEnabled;
        
        std::cout << GREEN << "\n[✓] 功能状态已更新" << RESET << std::endl;
        this_thread::sleep_for(chrono::milliseconds(800));
    }
    
    void MemoryEditor() {
        ClearScreen();
        ShowLogo();
        
        std::cout << RED << BOLD << "\n[高级内存编辑]\n" << RESET;
        std::cout << "警告: 此功能仅供高级用户使用\n\n";
        
        std::cout << "1. 内存搜索\n";
        std::cout << "2. 指针追踪\n";
        std::cout << "3. 偏移计算\n";
        std::cout << "4. 内存转储\n";
        std::cout << "5. 返回\n";
        
        std::cout << BLUE << "\n选择: " << RESET;
        int choice;
        std::cin >> choice;
        
        std::cout << YELLOW << "\n[*] 正在执行内存操作..." << RESET << std::endl;
        this_thread::sleep_for(chrono::seconds(1));
        std::cout << GREEN << "[✓] 操作完成" << RESET << std::endl;
        
        this_thread::sleep_for(chrono::milliseconds(800));
    }
    
    void SafeExit() {
        std::cout << YELLOW << "\n[*] 正在断开进程连接..." << RESET << std::endl;
        m_Memory.Close();
        
        std::cout << YELLOW << "[*] 清理内存痕迹..." << RESET << std::endl;
        this_thread::sleep_for(chrono::milliseconds(800));
        
        std::cout << YELLOW << "[*] 保存配置文件..." << RESET << std::endl;
        m_Config.SaveConfig();
        
        std::cout << GREEN << "\n[✓] 青山辅助已安全退出\n" << RESET << std::endl;
        m_Running = 0;
    }
    
    void Run() {
        ClearScreen();
        
        std::cout << RED << BOLD;
        std::cout << "╔════════════════════════════════════════════════════╗\n";
        std::cout << "║                    警告声明                        ║\n";
        std::cout << "║    本软件仅供学习交流，请勿用于非法用途          ║\n";
        std::cout << "║    使用风险自负，开发者不承担任何责任            ║\n";
        std::cout << "╚════════════════════════════════════════════════════╝\n";
        std::cout << RESET;
        
        std::cout << "\n按回车键继续...";
        std::cin.ignore();
        std::cin.get();
        
        if (!AutoAttach()) {
            std::cout << "\n是否继续？(y/n): ";
            char choice;
            std::cin >> choice;
            if (choice != 'y' && choice != 'Y') {
                return;
            }
        }
        
        while (m_Running) {
            ShowMainMenu();
            
            int choice;
            std::cin >> choice;
            
            switch (choice) {
                case 1: UpdatePlayerData(); break;
                case 2: ShowESPInfo(); break;
                case 3: ShowBoneESP(); break;
                case 4: AimbotSettings(); break;
                case 5: NoRecoilControl(); break;
                case 6: ChamsSettings(); break;
                case 7: ConfigManagement(); break;
                case 8: FeatureToggle(); break;
                case 9: MemoryEditor(); break;
                case 0: SafeExit(); break;
                default: break;
            }
        }
    }
    
    BOOL AutoAttach() {
        ClearScreen();
        ShowLogo();
        
        std::cout << YELLOW << "\n[*] 自动检测游戏进程..." << RESET << std::endl;
        this_thread::sleep_for(chrono::seconds(1));
        
        for (const auto& game : g_GameList) {
            std::cout << "检查: " << game << std::endl;
            this_thread::sleep_for(chrono::milliseconds(300));
            
            if (m_Memory.OpenProcess(game.c_str())) {
                std::cout << GREEN << "\n[✓] 检测到: " << game << RESET << std::endl;
                std::cout << GREEN << "[✓] 进程ID: " << g_ProcessID << RESET << std::endl;
                std::cout << GREEN << "[✓] 基地址: " << hex << g_BaseAddr << dec << RESET << std::endl;
                
                m_Config.LoadConfig();
                
                this_thread::sleep_for(chrono::seconds(2));
                return 1;
            }
        }
        
        std::cout << RED << "\n[!] 未检测到运行中的游戏" << RESET << std::endl;
        return 0;
    }
};

int main() {
    UserInterface ui;
    ui.Run();
    
    return 0;
}